package com.cg.obs.bean;

public class RequestTable
{
	private int custId;
	private String type;
	private float balance;
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	public RequestTable(int custId, String type, float balance) {
		super();
		this.custId = custId;
		this.type = type;
		this.balance = balance;
	}
	public RequestTable() {
		super();
	}
	@Override
	public String toString() {
		return "RequestTable [custId=" + custId + ", type=" + type
				+ ", balance=" + balance + "]";
	}
	
}
