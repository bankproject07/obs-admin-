package com.cg.obs.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.obs.bean.Admin;
import com.cg.obs.bean.RequestTable;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.Users;
import com.cg.obs.exception.UserException;
import com.cg.obs.service.IUserService;
import com.cg.obs.service.UserServiceImpl;


@WebServlet(urlPatterns={"/BankingApplicationController","/Login","/AdminLogin","/viewTransaction","/Daily","/Monthly","/Yearly",
		"/Registration"})
public class BankingApplicationController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	IUserService userService;
    public BankingApplicationController() {
        
    	userService=new UserServiceImpl();
    }

	public void init(ServletConfig config) throws ServletException {
		
	}

	public void destroy() {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String path=request.getServletPath();
		String url="";
		
		switch(path)
		{
		case "/Login":
			
			String id=request.getParameter("txtUserName");
			String password=request.getParameter("txtPassword");
			
			int hitCounter=0;
			Users user=userService.getUser(Integer.parseInt(id));
			System.out.println(user);
			if(user!=null)
				{
				if(user.getLockStatus()!="L")
					
				{
					
					if(password.equalsIgnoreCase(user.getLoginPassword()))
					{
						System.out.println(user.getLoginPassword());
						url="Sucess.jsp";
						request.setAttribute("userid", user.getUserId());
					}
					else
					{
						hitCounter++;
						System.out.println(hitCounter);
						if(hitCounter==3)
						{
							userService.updateLockStatus(user.getUserId());
							System.out.println("Your Account Locked");
							url="#";
						}
					url="#";
					}
				}
				else
				{
					System.out.println("Wrong Password"+hitCounter);
				}
				}
		else
		{
			throw new UserException("No User Exists.....");
		}
			break;
		
		case "/AdminLogin":
			String adUser = request.getParameter("username");
			String pass = request.getParameter("password");
			
			Admin ad = userService.getAdmin();
			if(ad!=null)
			{
				if(adUser.equalsIgnoreCase(ad.getAdminid())&&pass.equalsIgnoreCase(ad.getAdminPassword()) ){
					url ="AdminAccount.jsp";
				}
			}
			break;
			
		case "/ViewRequest":
				
			break;
			
		case "/viewTransaction":
			url="TypeOfTrans.jsp";
			
			break;
		case "/Daily":
			System.out.println("jhgjhg");
			String startDate = request.getParameter("date");
			java.sql.Date sqlStartDate;
			try
			{
				SimpleDateFormat sdf1 = new SimpleDateFormat("dd-mm-yyyy");
				java.util.Date date = sdf1.parse(startDate);
				sqlStartDate = new java.sql.Date(date.getTime());
				
				List<Transactions> tList = userService.viewDailyReport(sqlStartDate);
				request.setAttribute("tList", tList);
				url="./Projects/pages/DailyTransactions.jsp";
				
			} 
			catch (ParseException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
			break;
			
		case "/Monthly":
			String strtDate = request.getParameter("sdate");
			java.sql.Date sqlStrtDate;
			String endDate = request.getParameter("edate");
			java.sql.Date sqlEndDate;
			try
			{
				SimpleDateFormat sdf1 = new SimpleDateFormat("dd-mm-yyyy");
				java.util.Date sdate = sdf1.parse(strtDate);
				sqlStrtDate = new java.sql.Date(sdate.getTime());
				
				SimpleDateFormat edf1 = new SimpleDateFormat("dd-mm-yyyy");
				java.util.Date edate = edf1.parse(endDate);
				sqlEndDate = new java.sql.Date(edate.getTime());
				
				List<Transactions> tList = userService.viewMonthlyReport(sqlStrtDate, sqlEndDate);
				request.setAttribute("tList", tList);
				url="./Projects/pages/DailyTransactions.jsp";
				
			} 
			catch (ParseException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
			break;
			
		case "/Yearly":
			
			String sDate = request.getParameter("sdate");
			java.sql.Date sqlSDate;
			String eDate = request.getParameter("edate");
			java.sql.Date sqlEDate;
			try
			{
				SimpleDateFormat sdf2 = new SimpleDateFormat("dd-mm-yyyy");
				java.util.Date sdate = sdf2.parse(sDate);
				sqlSDate = new java.sql.Date(sdate.getTime());
				
				SimpleDateFormat edf2 = new SimpleDateFormat("dd-mm-yyyy");
				java.util.Date edate = edf2.parse(eDate);
				sqlEDate = new java.sql.Date(edate.getTime());
				
				List<Transactions> tList = userService.viewYearlyReport(sqlSDate, sqlEDate);
				request.setAttribute("tList", tList);
				url="./Projects/pages/DailyTransactions.jsp";
				
			} 
			catch (ParseException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			break;
		case "/Registration":
			int custid = Integer.parseInt(request.getParameter("txtCustId"));
			String type = request.getParameter("type");
			float bal = Float.parseFloat(request.getParameter("txtBal"));
			
			RequestTable resTab= null;
			resTab.setCustId(custid);
			resTab.setType(type);
			resTab.setBalance(bal);
			
			int cid = userService.addRequest(resTab);
			request.setAttribute("CustID", cid);
			url="SuccessReg.jsp";
			break;
		}
				
			RequestDispatcher rd=request.getRequestDispatcher(url);
			rd.forward(request, response);
			
			
			
		}
		
		
		
		
	}


