package com.cg.testing;

import java.sql.Date;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.swing.text.DateFormatter;

import com.cg.obs.bean.AccountMaster;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.RequestTable;
import com.cg.obs.bean.Transactions;
import com.cg.obs.exception.UserException;
import com.cg.obs.service.IUserService;
import com.cg.obs.service.UserServiceImpl;

public class ManualTestin {

	public static void main(String[] args) throws ParseException 
	{
	
		IUserService service= new UserServiceImpl();
		
		Scanner sc = new Scanner(System.in);
		/*	System.out.println("Enter Customer Id :" );
		int custisd = sc.nextInt();
		Customer cust=null;
		try
		{
			cust = service.getCustomer(custisd);
			
			System.out.println(cust);
		} 
		catch (UserException e)
		{
			System.out.println(e.getMessage());
		}
		*
		*/
		
		/*//customer
		System.out.println("Customer name :");
		String name=sc.next();
		
		System.out.println("Address :");
		String add = sc.next();
		System.out.println("email");
		String email = sc.next();
		System.out.println("pan card :");
		String pan =sc.next();
		
		
		
		//account
		System.out.println("Account type :");
		String type = sc.next();
		System.out.println("Balance ");
		float bal = sc.nextFloat();
		System.out.println("Open date");
		String opendate = sc.next();
		SimpleDateFormat sdf1 = new SimpleDateFormat("dd-mm-yyyy");
		java.util.Date date = sdf1.parse(opendate);
		java.sql.Date sqlStartDate = new java.sql.Date(date.getTime());  
		
		
		
		
		
		 * 
		 * String startDate="01-02-2013";
SimpleDateFormat sdf1 = new SimpleDateFormat("dd-mm-yyyy");
java.util.Date date = sdf1.parse(startDate);
java.sql.Date sqlStartDate = new java.sql.Date(date.getTime());  
		 
		
		Customer cust = new Customer();
		AccountMaster acc = new AccountMaster();
		
		cust.setCustomer_Name(name);
		cust.setAddress(add);
		cust.setEmail(email);
		cust.setPancard(pan);
		
		acc.setAccountType(type);
		acc.setAccount_bal(bal);
		acc.setOpen_date(sqlStartDate);
		
		
	//	int accid = service.addUsers(cust, acc);
	//	System.out.println("Account added with account id :" +accid);
		
		
*/	
		
		/*RequestTable res = new RequestTable();
		res.setCustId(1500230);
		res.setType("Saving");
		res.setBalance(2500);
		System.out.println(res);
		int custid = service.addRequest(res);
		System.out.println("cust id "+custid);
		*/
		
		Transactions trans = new Transactions();
		System.out.println("Enter start date :");
		String startDate = sc.nextLine();
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd-mm-yyyy");
			java.util.Date date = sdf1.parse(startDate);
			java.sql.Date sqlStartDate = new java.sql.Date(date.getTime()); 
		
		System.out.println("Enter end date :");
		String endDate = sc.nextLine();
		
			SimpleDateFormat edf1 = new SimpleDateFormat("dd-mm-yyyy");
			java.util.Date edate = edf1.parse(startDate);
			java.sql.Date sqlEndDate = new java.sql.Date(edate.getTime()); 
			
		List<Transactions> list = service.viewMonthlyReport(sqlStartDate, sqlEndDate);
		Iterator<Transactions> it = list.iterator();
		
		while(it.hasNext())
		{
			trans = it.next();
			System.out.println(trans.getTransaction_ID() +"\t" +trans.getTran_Description()+"\t"+trans.getDateOfTransaction()+"\t"
					+trans.getTransactionType()+"\t"+trans.getTransactionAmount()+"\t"+trans.getAccountID());
		}
		
		}

}
