select * from ACCOUNT_MASTER;

select * from CUSTOMER ;

select custid_seq.nextVal from dual;

select accid_seq.nextVal from dual;