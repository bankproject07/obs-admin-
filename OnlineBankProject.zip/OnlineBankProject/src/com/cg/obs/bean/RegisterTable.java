package com.cg.obs.bean;

public class RegisterTable
{
	private int registerId;
	private String custName;
	private String address;
	private String email;
	private String pancard;
	private int mobile;
	private String accountType;
	public int getRegisterId() {
		return registerId;
	}
	public void setRegisterId(int registerId) {
		this.registerId = registerId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public RegisterTable(int registerId, String custName, String address, String email, String pancard, int mobile,
			String accountType) {
		super();
		this.registerId = registerId;
		
		this.custName = custName;
		this.address = address;
		this.email = email;
		this.pancard = pancard;
		this.mobile = mobile;
		this.accountType = accountType;
	}
	@Override
	public String toString() {
		return "RegisterTable [registerId=" + registerId + ", custName=" + custName + ", address=" + address
				+ ", email=" + email + ", pancard=" + pancard + ", mobile=" + mobile + ", accountType=" + accountType
				+ "]";
	}
	public RegisterTable() {
		super();
	}
	
}
