package com.cg.obs.service;


import java.sql.Date;
import java.util.List;

import com.cg.obs.bean.AccountMaster;
import com.cg.obs.bean.Admin;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.FundTransfer;
import com.cg.obs.bean.RequestTable;
import com.cg.obs.bean.ServiceTracker;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.Users;
import com.cg.obs.dao.AdminDaoImpl;
import com.cg.obs.dao.IAdminDao;
import com.cg.obs.dao.IUserDAO;
import com.cg.obs.dao.UserDAOImpl;
import com.cg.obs.exception.UserException;

public class UserServiceImpl implements IUserService {

	IUserDAO userDao;
	IAdminDao adminDao;
	public UserServiceImpl() {
		userDao=new UserDAOImpl();
		adminDao=new AdminDaoImpl();
	}
	
	
	
	@Override
	public Users getUser(int id) throws UserException {
		
		return userDao.getUser(id);
	}

	@Override
	public Admin getAdmin() throws UserException {
		
		return adminDao.getAdmin();
	}



	@Override
	public List<Transactions> getMiniTransactions(Long accountno) throws UserException {
		
		return userDao.getMiniTransactions(accountno);
	}

	
	@Override
	public List<Transactions> getDetailedTransactions(Long accountno) throws UserException {

		return userDao.getDetailedTransactions(accountno);
	}



	@Override
	public void updateCustomerDetails(Customer customer) throws UserException {
	
		userDao.updateCustomerDetails(customer);
	}


	@Override
	public int requestService(ServiceTracker services) throws UserException {
		
		return userDao.requestService(services);
	}



	@Override
	public int fundTransfer(FundTransfer transferInfo) throws UserException {
		// TODO Auto-generated method stub
		return userDao.fundTransfer(transferInfo);
	}



	@Override
	public void changePassword(Users user) throws UserException {

		userDao.changePassword(user);
		
	}



	@Override
	public void updateLockStatus(int userid) throws UserException {
		
		userDao.updateLockStatus(userid);
		
	}




	@Override
	public int registerUser(Users user, Customer customer) throws UserException {
		
		return userDao.registerUser(user, customer);
	}



	@Override
	public Customer getCustomer(int id) throws UserException {
		
		return adminDao.getCustomer(id);
	}



	@Override
	public int addUsers(Customer customer) throws UserException {
		// TODO Auto-generated method stub
		return adminDao.addUsers(customer);
	}



	@Override
	public int addUsers(AccountMaster accountMaster) throws UserException {
		// TODO Auto-generated method stub
		return adminDao.addUsers(accountMaster);
	}



	@Override
	public int addRequest(RequestTable resTab) throws UserException {
		// TODO Auto-generated method stub
		return userDao.addRequest(resTab);
	}



	@Override
	public List<Transactions> viewMonthlyReport(Date StartDate, Date EndDate) throws UserException {
		// TODO Auto-generated method stub
		return adminDao.viewMonthlyReport(StartDate, EndDate);
	}



	@Override
	public List<Transactions> viewYearlyReport(Date StartDate, Date EndDate) throws UserException {
		// TODO Auto-generated method stub
		return adminDao.viewYearlyReport(StartDate, EndDate);
	}



	@Override
	public List<Transactions> viewDailyReport(Date StartDate) throws UserException {
		// TODO Auto-generated method stub
		return adminDao.viewDailyReport(StartDate);
		
	}
	
	

}
